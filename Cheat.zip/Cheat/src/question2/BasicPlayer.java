package question2;
/**
 * The representation of a player in the game
 */

/**
 *
 * @author Bijan
 */
public class BasicPlayer implements Player{

    Hand hand = new Hand();
    Strategy s;
    CardGame g;    
    
    public BasicPlayer(Strategy s, BasicCheat bc){
        
        this.g = bc;
        this.s = s;
        
    }
    
    /**add to the players hand
    * @param c: Card to add
    */
    @Override
    public void addCard(Card c) {        
        hand.addCard(c);        
    }

    /**
    * 	add all the cards in h to the players hand
    * @param h: hand to add
    */
    @Override
    public void addHand(Hand h) {        
        hand.add(h);
    }

    /**
    * @return number of cards left in the players hand
    */
    @Override
    public int cardsLeft() {
        return hand.getHandSize();
    }

    /**
    * @param g: the player should contain a reference to the game it is playing in
    */
    @Override
    public void setGame(CardGame g) {
        this.g = g;
    }

    /**	
    * @param s: the player should contain a reference to its strategy
    */
    @Override
    public void setStrategy(Strategy s) {
        this.s = s;
    }

    /**
    * Constructs a bid when asked to by the game. 	
    * @param b: the last bid accepted by the game. .
    * @return the players bid
    */
    @Override
    public Bid playHand(Bid b) {
        
        boolean flag = s.cheat(b, hand);
        b = s.chooseBid(b, hand, flag);
        
        return b;
    }

    /**
    * 
    * @param b: the last players bid
    *
    * @return true if calling the last player a cheat.
    */
    @Override
    public boolean callCheat(Bid b) {                
        
        return s.callCheat(hand, b);
    }
    
    
    
}
