package question2;
/**
 *
 * @author Bijan
 */
public class StrategyFactory {

    public enum StrategyType {HUMAN, THINKER, MYSTRATEGY}
    
    
    public Strategy setPlayersStrategy(StrategyType strategy){
                
        switch(strategy){
            case HUMAN: return new Human();
            case THINKER: return new Thinker();
            case MYSTRATEGY: return new MyStrategy();
            default: System.out.println("Invalid sterategy"); return null;
        }                
    }
        
}
