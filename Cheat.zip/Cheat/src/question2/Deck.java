package question2;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Random;

/*
 * This class represents the entity of a Deck of Cards.
 */

/**
 * 24/01/2017
 * @author Bijan (100125463)
 */
public class Deck implements Iterable<Card>, Serializable {
    
    
    ArrayList<Card> cards;    
    // Declaring serialVersionUID and enum types
    static final long serialVersionUID = 101L;    
         
    
    public Deck(){
        
        cards = new ArrayList<Card>();        
        
        for(int i = 0; i < 4; i++){
            Card.Suit suit = Card.Suit.values()[i];
            for(int j = 0; j < 13; j++){
                Card.Rank rank = Card.Rank.values()[j];
                Card card = new Card(rank, suit);
//                System.out.println(card);
                cards.add(card);
            }
        }
    }
    
    public Card deal(){
        
        Card topCard;
        int limit = cards.size();
        topCard = cards.get(0);
        for(int i = 0; i < limit; i++){
            if(i == limit -1){
                cards.remove(i);                
            } else {                
                cards.set(i, cards.get(i + 1));
            }
        }
        
        return topCard;
    }
       
    /*
     * Returns the size of the deck of cards
     */
    public int size(){
        return cards.size();
    }
    
    /*
     * removes the elements of the Cards List and initialises a new list of cards
     */
    public final void newDeck(){
        
        Card thisCard;
        int size = cards.size();
        int counter = 0;
        
       
        cards.clear();
      
        for(int i = 0; i < 4; i++){
            Card.Suit suit = Card.Suit.values()[i];
            for(int j = 0; j < 13; j++){
                Card.Rank rank = Card.Rank.values()[j];
                Card card = new Card(rank, suit);                
                cards.add(card);
            }
        }
    }
    
    /*
     * Shuffles the cards of a deck by swaping 2 random cards 100 times
     */
    public void shuffle(){
        
        Card container1;
        Card container2;
        int randomNumber1;
        int randomNumber2;
        Random randy = new Random();
        
        for(int i = 0; i < 100; i++){
            randomNumber1 = randy.nextInt(52);
            randomNumber2 = randy.nextInt(52);            
            container1 = cards.get(randomNumber1);            
            container2 = cards.get(randomNumber2);            
            cards.set(randomNumber1, container2);            
            cards.set(randomNumber2, container1);            
        }
    }
    
    /*
     * Method for sorting the cards list to an Odd Even Order
     */
    public void sortOddEvenOrder(){
        
        ArrayList<Card> newCardList = new ArrayList<Card>();
        
        Card card;
        OddEvenIterator it = new  OddEvenIterator();
        while(it.hasNext()){
            card = it.next();
            newCardList.add(card);
        }
        
        cards.clear();
        
        for(Card c: newCardList){
            cards.add(c);
        }
        
        for(Card c: cards){
            System.out.println(c);
        }
    }
    
    private void writeObject(ObjectOutputStream out) throws IOException{
        
        sortOddEvenOrder();
        out.defaultWriteObject();
        
    }

    private void readObject(ObjectInputStream in) throws 
            IOException, ClassNotFoundException{
        
        
        in.defaultReadObject();
        cards.clear();         
    }
    
    @Override
    public Iterator<Card> iterator() {

        OddEvenIterator it = new  OddEvenIterator();
        
        return it;
    }
    
    public class OddEvenIterator implements Iterator<Card>{

        private int size = cards.size() - 1;
        private int index = 1;
        private int forRemove;
        
        @Override
        public boolean hasNext() {            
                        
            if(index > size){                
                if(index % 2 != 0){
                    index = 0;                    
                    return true;
                } else {
                    return false;
                }
            }
            return true;
        }

        @Override
        public Card next() {                 
            
            Card card;
            card = cards.get(index);
            forRemove = index;            
            index = index + 2;   
            return card;
            
        }
        
        @Override
        public void remove(){            
            if(index > size){
                if(index % 2 == 0){
                    for(int i = 0; i < cards.size(); i++){
                        cards.remove(i);
                    }
                }
            }
        }
        
    }
    
}
