package question2;
import java.util.ArrayList;

/**
 *
 * @author Bijan
 */
public class MyStrategy extends BasicStrategy implements Strategy{

    ArrayList<Bid> bidsPlayed = new ArrayList<Bid>();
    
    public int numberOfCardsPlayed(){
        int sum = 0;
        for(int i = 0; i < bidsPlayed.size(); i++){
            sum += bidsPlayed.get(i).h.getHandSize();
        }
        return sum;
    }
    
    /**
     * Cheats if it there is no card with the same of next rank of the past bid
     * @param b: The pass bid played by the previous player
     * @param h: The player's hand of cards
     * @return : true if cheating; false otherwise
     */
    @Override
    public boolean cheat(Bid b, Hand h) {
        Card.Rank rank = b.getRank();
        
        if(((h.countRank(rank)) == 0) && (h.countRank(rank.getNext(rank)) == 0)){
            return true;
        } else if(!h.isStraight() && numberOfCardsPlayed() < 4){            
            return true;
        } else {
            return false;
        }
        
    }

    /**
     * If cheating chooses a card from the rank with the most cards in the hand
     * if NOT cheating uses all the cards possible with the lowest rank possible
     * @param b: The pass bid played by the previous player
     * @param h: The player's hand of cards
     * @param cheat: true if player has to cheat; false otherwise
     * @return : The bid that the player has to play for their turn
     */
    @Override
    public Bid chooseBid(Bid b, Hand h, boolean cheat) {
        
        Bid newBid = new Bid();
        
        // If Cheating *********************************************************
        if(cheat){
                        
            newBid.setRank(b.getRank().getNext(b.getRank()));            
                        
            int maximumRank = 0;
            Card.Rank r = null;
            Card.Rank mostRanks = null;            
            
            for(int i = 0; i < 13; i++){
                if(h.countRank(r.values()[i]) > maximumRank){
                    mostRanks = r.values()[i];
                    maximumRank = h.countRank(r.values()[i]);
                }
            }
            
            int counter = 0;
            boolean stop = false;
            while(!stop){                
                if(h.getCard(counter).getRank() == mostRanks){                                                           
                    newBid.h.addCard(h.getCard(counter));
                    h.removeCardWithIndex(counter);
                    stop = true;
                }
                counter++;
            }
            
            // If NOT Cheating *************************************************
        } else {
            
            Card.Rank rank = b.getRank();
            int numberOfRanks = h.countRank(rank);
            newBid.setRank(b.r); 
            
            if(numberOfRanks == 0){
                rank = b.getRank().getNext(rank);
                numberOfRanks = h.countRank(rank);
                newBid.setRank(rank); 
            }
            
            Card[] cards = new Card[numberOfRanks];            
            int counter = 0;
            int index = 0;
            int[] indexesToBeRemoved = new int[numberOfRanks];
            
            
            while(counter < numberOfRanks){
                if(h.getCard(index).getRank() == newBid.getRank()){                    
                    cards[counter] = h.getCard(index);                    
                    newBid.h.addCard(cards[counter]);
                    indexesToBeRemoved[counter] = counter;
                    counter++;
                }
                index++;
            }
            
            for(int i = 0; i < indexesToBeRemoved.length; i++){
                h.removeCardWithIndex(indexesToBeRemoved[i]);
            }
            
        }
        bidsPlayed.add(newBid);
        return newBid;
    }

    /**
     * Calls cheat if the number of cards played with the same rank is more than 4
     * @param h: The player's hand of cards
     * @param b: The pass bid played by the previous player
     * @return : True if player wants to call cheat; false otherwise
     */
    @Override
    public boolean callCheat(Hand h, Bid b) {
        
        int cardsPlayedInBid;
        
        for(int i = 0; i < bidsPlayed.size(); i++){
            if(bidsPlayed.get(i).getRank() == b.getRank()){
                Card.Rank rankOfThePlayedBid = bidsPlayed.get(i).getRank();
                cardsPlayedInBid = bidsPlayed.get(i).h.countRank(rankOfThePlayedBid)
                        + b.h.countRank(b.getRank());
                
                if(cardsPlayedInBid > 4){
                    return true;
                }
            }
        }                
                
        if(b.h.getHandSize() > 4){
            return true;
        }
        
        // Call cheat if the cards discarded are less than 4 and you don't have
        // any cards related to the current bid's rank
        if(numberOfCardsPlayed() < 4 && h.countRank(b.getRank()) == 0 
                && h.countRank(b.getRank().getNext(b.getRank())) == 0){
            return true;
        }
        
        if(h.countRank(b.getRank()) == 4 && !b.h.getCards().isEmpty()){
            return true;
        } else {
            return false;
        }                    
    }
    
}
