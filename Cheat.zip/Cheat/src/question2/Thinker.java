﻿package question2;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Bijan
 */
public class Thinker extends BasicStrategy implements Strategy{
    
    ArrayList<Hand> cardsPlayed = new ArrayList<Hand>();
    
    /**
     * Cheat if it has to. It should also occasionally cheat when it doesn’t have to
     * @param b: The pass bid played by the previous player
     * @param h: The player's hand of cards
     * @return : true if cheating; false otherwise
     */
    @Override
    public boolean cheat(Bid b, Hand h) {
        
        Card.Rank rank = b.getRank();
        Random rand = new Random();
        int cheat = rand.nextInt(10) + 1;
        
        if(((h.countRank(rank)) == 0) && (h.countRank(rank.getNext(rank)) == 0)){
            return true;
        } else if(cheat <= 3){
            return true;
        } else {
            return false;
        }
                
    }

    /**
     * If cheating, the Thinker should be more likely to choose higher cards
     * to discard than low cards. If not cheating, it should usually play all
     * its cards but occasionally play a random number
     * @param b: The pass bid played by the previous player
     * @param h: The player's hand of cards
     * @param cheat: true if player has to cheat; false otherwise
     * @return : The bid that the player has to play for their turn
     */
    @Override
    public Bid chooseBid(Bid b, Hand h, boolean cheat) {
        
        Card card = null;
        Bid newBid = new Bid();        
        Hand handToList = new Hand();
        
        if(cheat){
            
            newBid.setRank(b.getRank().getNext(b.getRank()));
            
            Random rand = new Random();                        
            int randomIndex = rand.nextInt(h.getHandSize());
            card = h.getCard(randomIndex);
            handToList.addCard(card);
            cardsPlayed.add(handToList);
            handToList.removeCardsFromHand(handToList);
            h.removeCard(card);                        
            newBid.h.addCard(card);                             
            
        } else {
            
            Card.Rank rank = b.getRank();
            int numberOfRanks = h.countRank(rank);
            newBid.setRank(b.r); 
            Random rand = new Random();            
            
            if(numberOfRanks == 0){
                rank = b.getRank().getNext(rank);
                numberOfRanks = h.countRank(rank);
                newBid.setRank(rank); 
            }
            
            int randomNumber = rand.nextInt(numberOfRanks) + 1;
            int randomChance = rand.nextInt(10) + 1;
            Card[] cards = new Card[numberOfRanks];            
            int counter = 0;
            int index = 0;
            int[] indexesToBeRemoved = new int[numberOfRanks];
            
            if(randomChance <= 3){
                
                while(counter < randomNumber){
                if(h.getCard(index).getRank() == newBid.getRank()){                    
                    cards[counter] = h.getCard(index);                    
                    newBid.h.addCard(cards[counter]);
                    handToList.addCard(card);
                    cardsPlayed.add(handToList);                    
                    indexesToBeRemoved[counter] = counter;
                    counter++;
                }
                index++;
            }
                handToList.removeCardsFromHand(handToList);
            } else {
                
                while(counter < numberOfRanks){
                if(h.getCard(index).getRank() == newBid.getRank()){                    
                    cards[counter] = h.getCard(index);                    
                    newBid.h.addCard(cards[counter]);
                    handToList.addCard(card);
                    cardsPlayed.add(handToList); 
                    indexesToBeRemoved[counter] = counter;
                    counter++;
                }
                index++;
            }
                handToList.removeCardsFromHand(handToList);
            }                        
            
            for(int i = 0; i < indexesToBeRemoved.length; i++){
                h.removeCardWithIndex(indexesToBeRemoved[i]);
            }
            
        }
        
        return newBid;
    }

    /**
     * The Thinker should attempt to make an informed decision to call cheat on another player
     * @param h: The player's hand of cards
     * @param b: The pass bid played by the previous player
     * @return : True if player wants to call cheat; false otherwise
     */
    @Override
    public boolean callCheat(Hand h, Bid b) {
        
        for(int i = 0; i < cardsPlayed.size(); i++){
            if(cardsPlayed.get(i).countRank(b.getRank()) >= 4){
                return true;
            }
            
            int cardsPlayedForRank = (cardsPlayed.get(i).countRank(b.getRank())) 
                + (b.getHand().getHandSize());
            
            if(cardsPlayedForRank > 4){
                return true;
            }
        }                
        
        if(b.h.getHandSize() > 4){
            return true;
        }
        
        if(h.countRank(b.getRank()) == 4 && !b.h.getCards().isEmpty()){
            return true;
        } else {
            return false;
        }
                
    }
}
