package question2;
/**
 * This class let's the user to play role of a player
 */
import java.util.Scanner;

/**
 *
 * @author Bijan
 */
public class Human extends BasicStrategy implements Strategy{
        
    /**
     * Shows the cards that the player has in their hand of cards
     * @param hand : The player's hand of cards
     */
    public void showCards(Hand hand){
        System.out.println("This is your hand:\n");
        for(int i = 0; i < hand.getHandSize(); i++){
            System.out.println(i + " = " + hand.getCard(i));
        }
    }
  
    /**
     * Cheats if the user decides to
     * @param b: The pass bid played by the previous player
     * @param h: The player's hand of cards
     * @return : true if cheating; false otherwise
     */
    @Override
    public boolean cheat(Bid b, Hand h) {
        
        String response = null;
        Scanner scan = new Scanner(System.in);  
        boolean stop = false;
        boolean cheat = false;
        
        showCards(h);
        
        while(!stop){
            System.out.print("Would you like to cheat?(Y/N)");
            response = scan.next();
            if(response.equals("Y")){
                stop = true;
                cheat = true;
            } else if(response.equals("N")){
                if((h.countRank(b.getRank()) == 0) && 
                        (h.countRank(b.getRank().getNext(b.getRank())) == 0)){
                    System.out.println("You must cheat");
                } else{
                    stop = true;
                    cheat = false;
                }                
            } else {
                System.out.println("Not valid input");                
            }
        }
        
        return cheat;
    }

    /**
     * Let's the user choose their bid
     * @param b: The pass bid played by the previous player
     * @param h: The player's hand of cards
     * @param cheat: true if player has to cheat; false otherwise
     * @return : The bid that the player has to play for their turn
     */
    @Override
    public Bid chooseBid(Bid b, Hand h, boolean cheat) {
        
        int response = 0;
        Scanner scan = new Scanner(System.in);
        boolean stop = false;        
        Bid newBid = new Bid();
        int previousCard = 100;
        
        // IF cheating********************************************************************
        if(cheat){
            
            Card.Rank r = b.getRank();
            int indexOfRank = r.ordinal();
            int nextIndexOfRank = 0;
            int counter = 0;
            
            // choosing the RANK****************************************************
            while(!stop){                
                
                showCards(h);
                
                System.out.println("Choose a rank for the bid");            
                System.out.println(indexOfRank + " = " + r); 
                if(indexOfRank != 12){                    
                    nextIndexOfRank = indexOfRank + 1;
                    System.out.println(nextIndexOfRank + " = " + r.getNext(r));
                } else {
                    nextIndexOfRank = 0;
                    System.out.println(nextIndexOfRank + " = " + r.getNext(r));
                }                
                response = scan.nextInt();
                                
                
                if((response != indexOfRank) ||
                        (response != nextIndexOfRank)){
                    
                    stop = true;
                    newBid.setRank(r.values()[response]);
                    
                } else{                                        
                    System.out.println("You can't choose other ranks");
                    System.out.println("YOu choose " + indexOfRank + " or "
                    + (indexOfRank + 1) + "but you chose " + response);
                }
            }
            
            // choosing the CARDS****************************************************
            stop = false;
            while(!stop){
                
                System.out.print("Choose a card from the following\n");
                showCards(h);
                System.out.println("enter 20 for stop choosing");
                
                response = scan.nextInt();
                
                if(previousCard != response){
                    
                    if(response == 20){

                        if(newBid.h.getCards().isEmpty()){
                            System.out.println("You have to choose at least one card");                        
                        } else {
                            stop = true;
                        }   

                    } else if((response >= h.getHandSize()) || (response < 0)){                                     
                        System.out.println("Invalid input");
                    } else{                                        
                        newBid.h.addCard(h.getCard(response));
                        h.removeCardWithIndex(response);
                    }
                    
                } else {
                    System.out.println("You have already chosen this card");
                }                        
                previousCard = response;
            }                    
            
        } else { // IF NOT cheating********************************************************************
            
            Card.Rank r = b.getRank();
            int indexOfRank = r.ordinal();
            int nextIndexOfRank = 0;
            int counter = 0;                      
            
            // choosing the RANK****************************************************
            while(!stop){
                
                showCards(h);
                System.out.println("Choose a rank for the bid");            
                System.out.println(indexOfRank + " = " + r);            
                if(indexOfRank != 12){                    
                    nextIndexOfRank = indexOfRank + 1;
                    System.out.println(nextIndexOfRank + " = " + r.getNext(r));
                } else {
                    nextIndexOfRank = 0;
                    System.out.println(nextIndexOfRank + " = " + r.getNext(r));
                }                
                response = scan.nextInt();
                                
                
                if((response != indexOfRank) ||
                        (response != nextIndexOfRank)){
                    if(h.countRank(r.values()[response]) > 0){
                        stop = true;
                        newBid.setRank(r.values()[response]);
                    } else {
                        System.out.println("You don't have any card related to that rank");
                    }                                        
                } else{                 
                    System.out.println("You can't choose other ranks");
                    System.out.println("YOu choose " + indexOfRank + " or "
                    + (indexOfRank + 1) + " but you chose " + response);                    
                }
            }
            
            // choosing the CARDS****************************************************
            stop = false;
            while(!stop){                                
                
                System.out.print("Choose a card from the following\n");
                showCards(h);
                System.out.println("enter 20 for stop choosing");
                
                response = scan.nextInt();
                
                
                if(previousCard != response){
                    
                    
                    if(response == 20){

                        if(newBid.h.getCards().isEmpty()){
                            System.out.println("You have to choose at least one card");
                        } else {
                            stop = true;
                        }

                    } else if((response >= h.getHandSize()) || (response < 0)){
                        System.out.println("Invalid input");
                    } else if(h.getCard(response).getRank() != newBid.getRank()){
                        System.out.println("You have to choose a card with the "
                                + "same rank you chose before");
                    }else{                                        
                        newBid.h.addCard(h.getCard(response));
                        h.removeCardWithIndex(response);
                    }
                } else {
                    System.out.println("You have already chosen this card");
                }
                previousCard = response;
            }                
            
        }
        
        return newBid;
    }

    /**
     * Calls cheat if the player decides to
     * @param h: The player's hand of cards
     * @param b: The pass bid played by the previous player
     * @return : True if player wants to call cheat; false otherwise
     */
    @Override
    public boolean callCheat(Hand h, Bid b) {
        String response = null;
        Scanner scan = new Scanner(System.in);  
        boolean stop = false;
        boolean cheat = false;
        
        showCards(h);
        
        while(!stop){
            System.out.print("Would you like to call cheat?(Y/N)");
            response = scan.next();
            if(response.equals("Y")){
                stop = true;
                cheat = true;
            } else if(response.equals("N")){
                stop = true;
                cheat = false;
            } else {
                System.out.println("Not valid input");                
            }
        }
        
        return cheat;
    }
    
}