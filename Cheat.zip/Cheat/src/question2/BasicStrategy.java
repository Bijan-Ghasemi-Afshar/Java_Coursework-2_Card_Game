package question2;
import java.util.Random;

/*
 * 1. Never cheat unless you have to. If a cheat is required, play a single card selected randomly; 
 * 2. If not cheating, always play the maximum number of cards possible of the
 * lowest rank possible; 
 * 3. Call another player a cheat only when certain they are 
 * cheating (based on your own hand). 
 */

/**
 *
 * @author Bijan
 */
public class BasicStrategy implements Strategy{    
    
    /**
     * Cheats if it there is no card with the same of next rank of the past bid
     * @param b: The pass bid played by the previous player
     * @param h: The player's hand of cards
     * @return : true if cheating; false otherwise
     */
    @Override
    public boolean cheat(Bid b, Hand h) {
        
        Card.Rank rank = b.getRank();
        
        if(((h.countRank(rank)) == 0) && (h.countRank(rank.getNext(rank)) == 0)){
            return true;
        } else {
            return false;
        }        
    }

    /**
     * Chooses a bid for the player to play
     * @param b: The pass bid played by the previous player
     * @param h: The player's hand of cards
     * @param cheat: true if player has to cheat; false otherwise
     * @return : The bid that the player has to play for their turn
     */
    @Override
    public Bid chooseBid(Bid b, Hand h, boolean cheat) {
        
        Card card = null;
        Bid newBid = new Bid();
        
        
        System.out.println("Cheating = " +cheat);
        
        if(cheat){
            Random rand = new Random();                        
            int randomIndex = rand.nextInt(h.getHandSize());
            card = h.getCard(randomIndex);
            h.removeCard(card);                        
            newBid.h.addCard(card);
            randomIndex = rand.nextInt(2);            
            if(randomIndex == 1){
                newBid.setRank(b.getRank());
            } else {
                Card.Rank rank2 = b.getRank();
                rank2 = rank2.getNext(rank2);                
                newBid.setRank(rank2);
            }
            
        } else {
            
            
            Card.Rank rank = b.getRank();
            int numberOfRanks = h.countRank(rank);
            newBid.setRank(b.r); 
            
            if(numberOfRanks == 0){
                rank = b.getRank().getNext(rank);
                numberOfRanks = h.countRank(rank);
                newBid.setRank(rank); 
            }
            
            Card[] cards = new Card[numberOfRanks];            
            int counter = 0;
            int index = 0;
            int[] indexesToBeRemoved = new int[numberOfRanks];
            
            
            while(counter < numberOfRanks){
                if(h.getCard(index).getRank() == newBid.getRank()){                    
                    cards[counter] = h.getCard(index);                    
                    newBid.h.addCard(cards[counter]);
                    indexesToBeRemoved[counter] = counter;
                    counter++;
                }
                index++;
            }
            
            for(int i = 0; i < indexesToBeRemoved.length; i++){
                h.removeCardWithIndex(indexesToBeRemoved[i]);
            }
            
        }
        
        return newBid;
    }

    /**
     * Decides to call cheat or not by checking player's hand and the passed bid
     * @param h: The player's hand of cards
     * @param b: The pass bid played by the previous player
     * @return : True if player wants to call cheat; false otherwise
     */
    @Override
    public boolean callCheat(Hand h, Bid b) {
        
        if(h.countRank(b.getRank()) == 4 && !b.h.getCards().isEmpty()){
            return true;
        } else {
            return false;
        }        
    }
    
}
