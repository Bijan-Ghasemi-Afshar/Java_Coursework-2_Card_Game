package question1;

/*
 * This class represents the entity Card in a card game
 */

/**
 * 23/01/2017
 * @author Bijan (100125463)
 */

import java.io.Serializable;
import java.util.Comparator;

public class Card implements Serializable, Comparable<Card>{
    
    // Declaring serialVersionUID and enum types
    static final long serialVersionUID = 100L;

    
    // Declaring the enum types
    public enum Suit {CLUBS, DIAMONDS, HEARTS, PADES}  
    enum Rank{ TWO(2), THREE(3), FOUR(4), FIVE(5), SIX(6), SEVEN(7), EIGHT(8), 
        NINE(9), TEN(10), JACK(10), QUEEN(10), KING(10), ACE(11); 
    
        final int value; 

        Rank(int x){ 
            value=x; 
        } 

        public int getValue(){
            return value;
        } 
        
        public Rank getNext(Rank rank){
                        
            int rankNumber = rank.ordinal() + 1;
            if(rankNumber < 13){
                return Rank.values()[rankNumber];
            }
            if(rankNumber == 13){
                return Rank.values()[0];
            }
            
            return null;
        }
    }
    
    // Declaring variables
    private Rank rank;
    private Suit suit;
    
    /*
     * The card constructor 
     * To construct a Card object with Rank and Suit arguments passed to it
     */
    public Card(Rank rank, Suit suit){
        
        this.rank = rank;
        this.suit = suit;        
        
    }       

    /*
     * Returns the value of rank
     */
    public Rank getRank() {
        return rank;
    }
    
    /*
     * Returns the value of suit
     */
    public Suit getSuit(){
        return suit;
    }
    
    /*
     * Parameters - two Card objects to be compared in ranks
     * Returns - the difference in ranks between two cards 
     */
    public static int difference(Card card1, Card card2){
                        
        // Declaring variables to hold the card Ranks and their difference
        int cardRank1 = 0;
        int cardRank2 = 0;
        int difference = 0;
        
        // Getting the rank of the enums
        cardRank1 = card1.getRank().ordinal();
        cardRank2 = card2.getRank().ordinal();
        
        // Calculating the absolute value of difference
        difference = cardRank1 - cardRank2;
        difference = Math.abs(difference);
        
        return difference;
    }
    
    /*
     * Parameters - two Card objects to be compared in rank's value
     * Returns - the difference in rank's value between two cards 
     */
    public static int differenceValue(Card card1, Card card2){
        
        // Declaring variables to hold the card Ranks and their difference
        int card1Value = 0;
        int card2Value = 0;
        int difference = 0;
        
        // Getting the value of the enums
        card1Value = card1.getRank().getValue();
        card2Value = card2.getRank().getValue();
        
        // Calculating the absolute value of the difference in rank's value
        difference = card1Value - card2Value;
        difference = Math.abs(difference);
        
        return difference;
        
    }

    @Override
    public int compareTo(Card o) {
        
        int thisCardRank = this.getRank().ordinal();
        int otherCardRank = o.getRank().ordinal();       
        int thisCardSuit = this.getSuit().ordinal();
        int otherCardSuit = o.getSuit().ordinal();
        
        if((thisCardRank == otherCardRank && thisCardSuit > otherCardSuit) ||
                (thisCardRank > otherCardRank )){
            return 1;
        } else if(thisCardRank == otherCardRank && thisCardSuit ==
                otherCardSuit){
            return 0;
        } else if((thisCardRank == otherCardRank && 
                thisCardSuit < otherCardSuit) ||(thisCardRank < otherCardRank)){
            return -1;
        }
        
        return 0;
    }

    
    /*
     * Used to sort the cards into descending order by rank    
     */
    public static class CompareDescending implements Comparator<Card>{

        @Override
        public int compare(Card c1, Card c2) {
            
            int cardRank1 = c1.getRank().ordinal();
            int cardRank2 = c2.getRank().ordinal();
            
            
            if(cardRank1 > cardRank2){
                return -1;
            } else if(cardRank1 == cardRank2){
                return 0;
            } else if(cardRank1 < cardRank2){
                return 1;
            }
            
            return 0;
        }
    }
    
    /*
     * Used to sort into ascending order of suit
     */
    public static class CompareSuit implements Comparator<Card>{

        @Override
        public int compare(Card c1, Card c2) {
            
            int cardSuit1 = c1.getSuit().ordinal();
            int cardSuit2 = c2.getSuit().ordinal();
            

            if(cardSuit1 > cardSuit2){
                return 1;
            } else if(cardSuit1 == cardSuit2){
                return 0;
            } else if(cardSuit1 < cardSuit2){
                return -1;
            }
            
            return 0;
                        
        }
    }
    
    
    /*
     * Returns a string representation of the Card object
     */
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("Card{rank=");
        str.append(rank);
        str.append(", suit=");
        str.append(suit);
        str.append("}");
        return str.toString();
    }        
}
