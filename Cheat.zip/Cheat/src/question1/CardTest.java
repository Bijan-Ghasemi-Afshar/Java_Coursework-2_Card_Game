package question1;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/*
 * This class is used to test the functionality of the class Card
 */

/**
 * 23/01/2017
 * @author Bijan (100125463)
 */
public class CardTest {

    /**
     * @param args the command line arguments
     */
    
    
    public static void testCard() throws ClassNotFoundException{
        
        Card card1 = new Card(Card.Rank.TWO, Card.Suit.CLUBS);
        Card card1_1 = new Card(Card.Rank.TWO, Card.Suit.DIAMONDS);
        Card card2 = new Card(Card.Rank.THREE, Card.Suit.CLUBS);
        Card card3 = new Card(Card.Rank.ACE, Card.Suit.HEARTS);
        
        // Testing toString()
        System.out.println("Testing toString(): " + card1);
        System.out.println("Testing toString(): " + card1_1);
        System.out.println("Testing toString(): " + card2);
        System.out.println("Testing toString(): " + card3);
        
        // Testing getNext()
        System.out.println("Testing getNext(card1.getRank()): " + 
                card1.getRank().getNext(card1.getRank()));
        
        // Testing compareTo() (-1 for difference in rank)
        System.out.println("Testing card1.compareTo(card2) (-1 for difference in rank): " 
                + card1.compareTo(card2));
        
        // Testing compareTo() (-1 for difference in suit) 
        System.out.println("Testing card1.compareTo(card1_1) (-1 for difference in suit): " 
                + card1.compareTo(card1_1));
        
        // Testing compareTo() (1)
        System.out.println("Testing card2.compareTo(card1) (1): " 
                + card2.compareTo(card1));
        
        // Testing compareTo() (0)
        System.out.println("Testing card1.compareTo(card1) (0): " 
                + card1.compareTo(card1));
        
        // Testing getRank()
        System.out.println("Testing card1.getRank(): " + card1.getRank());
        
        // Testing getSuit()
        System.out.println("Testing card1.getSuit(): " + card1.getSuit());
        
        // Testing difference()
        System.out.println("Testing difference(card1, card2): " + 
                Card.difference(card1, card2));
        
        // Testing differenceValue ()
        System.out.println("Testing difference(card1, card3): " + 
                Card.differenceValue (card1, card3));
        
        // Testing CompareDescending compare()
        Card.CompareDescending cd = new Card.CompareDescending();
        System.out.println("Testing CompareDescending compare(card1, card3): " + 
                cd.compare(card1, card3));
        
        // Testing CompareDescending compareSuit()
        Card.CompareSuit cs = new Card.CompareSuit();
        System.out.println("Testing CompareDescending "
                + "compareSuit(card1, card3): " + cs.compare(card1, card3));
        
        // Testing  Serialization
        System.out.println("\nTesting  Serialization: ");
        String filename = "card.ser";
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
                        
        Card card = new Card(Card.Rank.KING, Card.Suit.HEARTS);        
        
        try{
            fos = new FileOutputStream(filename);
            out = new ObjectOutputStream(fos);
            out.writeObject(card);
            out.close();
        } catch (IOException ex){
            ex.printStackTrace();
        }

        FileInputStream fis = null;
        ObjectInputStream in = null;
        Card serializedCard = null;
        
        try{
            fis = new FileInputStream(filename);
            in = new ObjectInputStream(fis);
            
            serializedCard = (Card)in.readObject();
               
            in.close();
        } catch (IOException ex){
            ex.printStackTrace();
        }
        
        System.out.println(card);
    }
    
    public static void testDeck() throws ClassNotFoundException{
        
        Deck deck = new Deck();
        
        // Testing shuffle() 
        System.out.println("Testing shuffle(): ");
        deck.shuffle();        
        for(int i = 0; i < deck.cards.size(); i++){
            System.out.println(deck.cards.get(i));            
        }
        
        // Testing deal()
        System.out.println("Testing deal(): " + deck.deal());
        
        // Testing size()
        System.out.println("Testing size(): " + deck.size());
        
        // Testing newDeck()
        System.out.println("\nTesting newDeck(): ");
        deck.newDeck();
        for(int i = 0; i < deck.cards.size(); i++){
            System.out.println(deck.cards.get(i));            
        }
        
        // Testing OddEvenIterator iterator()
        System.out.println("\nTesting OddEvenIterator iterator(): ");        
        for(Card c: deck){
            System.out.println(c.toString());       
        }
        
        // Testing  Serialization
        System.out.println("\nTesting  Serialization: ");
        String filename = "deck.ser";
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
                        
        Deck deck1 = new Deck();        
        
        try{
            fos = new FileOutputStream(filename);
            out = new ObjectOutputStream(fos);
            out.writeObject(deck1);
            out.close();
        } catch (IOException ex){
            ex.printStackTrace();
        }

        FileInputStream fis = null;
        ObjectInputStream in = null;
        Deck serializedDeck = null;
        
        try{
            fis = new FileInputStream(filename);
            in = new ObjectInputStream(fis);
            
            serializedDeck = (Deck)in.readObject();
               
            in.close();
        } catch (IOException ex){
            ex.printStackTrace();
        }
        
        for(int i = 0; i < serializedDeck.size(); i++){
            System.out.println(deck.cards.get(i));
        }
        
    }
    
    public static void testHand() throws ClassNotFoundException{
        
        Deck deckForHand = new Deck();
        Card[] cardArray = new Card[10];
        
        for(int i = 0; i < 10; i++){
            cardArray[i] = deckForHand.cards.get(i);
        }
        
        Hand hand = new Hand(cardArray);
        
        // Testing countRanksAndSuits()
        hand.countRanksAndSuits();
        System.out.println("Testing countRanksAndSuits(): "); 
        
        System.out.println("The number of ranks: ");
        for(int i = 0; i < hand.rankCount.length; i++){
            System.out.print("*");
        }
        
        System.out.println("\nThe number of suits: ");
        for(int i = 0; i < hand.suitCount.length; i++){
            System.out.print("*");
        }
        
        System.out.println("");
        
        // Testing handValue()
        System.out.print("Testing handValue(): ");
        hand.handValue();
        System.out.println(hand.handTotalValue);
        
        // Testing addCard()
        Card newCard = new Card(Card.Rank.FOUR, Card.Suit.PADES);
        System.out.println("\nTesting addCard(newCard): ");
        hand.addCard(newCard);
        for(int i = 0; i < hand.getHandSize(); i++){
            System.out.println(hand.getCard(i));
        }
        
        // Testing addCollection()
        ArrayList<Card> cardCollection = new ArrayList<Card>();
        deckForHand.shuffle();
        for(int i = 0; i < 3; i++){
            cardCollection.add(deckForHand.cards.get(i));            
        }
        System.out.println("\nTesting addCollection(cardCollection): ");
        hand.addCollection(cardCollection);
        for(int i = 0; i < hand.getHandSize(); i++){
            System.out.println(hand.getCard(i));
        }
        
        // Testing addHand()
        Card[] newCardArray = new Card[6];
        deckForHand.shuffle();
        
        for(int i = 0; i < 6; i++){
            newCardArray[i] = deckForHand.cards.get(i);            
        }
        
        Hand newHand = new Hand(newCardArray);
        
        System.out.println("\nTesting addHand(newHand): ");
        hand.add(newHand);
        for(int i = 0; i < newHand.getHandSize(); i++){
            System.out.println(newHand.getCard(i));
        }
        
        // Testing removeCard()
        Card removeThisCard = newHand.getCard(0);
        System.out.println("\nTesting removeCard(removeThisCard): " 
                + newHand.removeCard(removeThisCard));
        
        // Testing removeCardWithIndex()        
        System.out.println("\nTesting removeCardWithIndex(0): " 
                + newHand.removeCardWithIndex(0));        
        
        // Testing removeCardsFromHand()        
        System.out.println("\nTesting removeCardsFromHand(): " 
                + newHand.removeCardsFromHand(newHand));
        
        // Testing iterator()        
        deckForHand.shuffle();
        for(int i = 0; i < 10; i++){
            cardCollection.add(deckForHand.cards.get(i));            
        }
        newHand.addCollection(cardCollection);        
        System.out.println("\nTesting iterator(): ");
        for(Card c:newHand.getCards()){
            System.out.println(c);
        }
        
        // Testing sortAscending()
        newHand.sortAscending();
        System.out.println("\nTesting sortAscending(): ");
        for(Card c:newHand.getCards()){
            System.out.println(c);
        }
        
        // Testing countSuit()        
        System.out.println("\nTesting countSuit(): " + 
                newHand.countSuit(Card.Suit.CLUBS));
        
        // Testing countRank()
        System.out.println("\nTesting countRank(): " + 
                newHand.countRank(Card.Rank.FIVE));
        
        // Testing toString()
        System.out.println("\nTesting toString()(): ");
        System.out.println(newHand);
        
        // Testing isFlush()
        Deck newDeck = new Deck();
        Card[] cardArray2 = new Card[5];
        for(int i = 0; i < 5; i++){
            cardArray2[i] = newDeck.cards.get(i);
        }
        Hand newHand2 = new Hand(cardArray2);
        System.out.println("\nTesting isFlush(): " + newHand2.isFlush());
        
        // Testing isStraight()
//        newHand2.addCard(new Card(Card.Rank.TWO, Card.Suit.HEARTS));
        System.out.println("\nTesting isStraight(): " + newHand2.isStraight());
        
        // Testing  Serialization
        System.out.println("\nTesting  Serialization: ");
        String filename = "hand.ser";
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
                        
        Deck deck1 = new Deck();  
        Card[] cardArray1 = new Card[6];
        for(int i = 0; i < 6; i++){
            cardArray1[i] = deck1.cards.get(i);
        }
        Hand hand1 = new Hand(cardArray1);
        
        try{
            fos = new FileOutputStream(filename);
            out = new ObjectOutputStream(fos);
            out.writeObject(hand1);
            out.close();
        } catch (IOException ex){
            ex.printStackTrace();
        }

        FileInputStream fis = null;
        ObjectInputStream in = null;
        Hand serializedHand = null;
        
        try{
            fis = new FileInputStream(filename);
            in = new ObjectInputStream(fis);
            
            serializedHand = (Hand)in.readObject();
               
            in.close();
        } catch (IOException ex){
            ex.printStackTrace();
        }
        
        for(int i = 0; i < serializedHand.getHandSize(); i++){
            System.out.println(serializedHand.getCard(i));
        }
    }
    
    public static void main(String[] args) throws 
            IOException, ClassNotFoundException {
             
        //Testing the class Card;
//        testCard();
//    
//        System.out.println("\n\n");

        //Testing the class Deck;
//        testDeck();
//        
//        System.out.println("\n\n");

        //Testing the class Deck
        testHand();

        

        
        
    }
  
}
