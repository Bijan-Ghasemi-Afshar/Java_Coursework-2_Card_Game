package question1;



import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

/*
 * This class represents the entity of a Hand in a Card game.
 */

/**
 * 25/01/2017
 * @author Bijan
 */
public class Hand implements Serializable, Iterable<Card>{
    
    static final long serialVersionUID = 102L;
    private ArrayList<Card> cards;
    int[] suitCount = new int[4];
    int[] rankCount = new int[13];
    int handTotalValue;
    
    public Hand(){
        
        cards = new ArrayList<Card>();
        
    }
    
    public Hand(Card[] cardsArray){
        
        cards = new ArrayList<Card>();
        
        for(int i = 0; i < cardsArray.length; i++){
            cards.add(cardsArray[i]);
        }
        
    }
    
    public Hand(Hand hand){
        
        cards = new ArrayList<Card>();
        
        for(Card c:hand.cards){
            
            cards.add(c);
            
        }
        
    }
    
    public void handValue(){
        
        handTotalValue = 0;
        
        for(Card c:cards){
            handTotalValue += c.getRank().getValue();
        }
        
    }
    
    public boolean isStraight (){
        
        int size = cards.size();
        countRanksAndSuits();
        
        if(size <= 13){
            for(int i = 0; i < rankCount.length; i++){
                if(rankCount[i] >= 2){
                    return false;
                } 
            }
            return true;
        } else {
            return false;
        }
    }
    
    public boolean isFlush(){
        
        int size = cards.size();
        countRanksAndSuits();
        for(int i = 0; i < 4; i++){
            if(size == suitCount[i]){
                return true;
            }
        }
        return false;
    }
    
    public Card removeCardWithIndex(int i){
        
        Card foundCard;
        foundCard = cards.get(i);
        cards.remove(i);
        
        return foundCard;
    }
    
    public boolean removeCardsFromHand(Hand hand){
        
        ArrayList<Card> newcards = hand.cards;
        Card c;        
        
        for(int i = 0; i < newcards.size(); i++){
            c = newcards.get(i);
            newcards.remove(c);
            if((newcards.size() - 1) == i){
                return true;
            }
        }
        
        return false;
    }
    
    public boolean removeCard(Card card){
        
        for(Card c:cards){
            int result = c.compareTo(card);
            if(result == 0){
                cards.remove(c);
                countRanksAndSuits();
                return true;
            }
        }
        return false;
    }
    
    public void add(Hand hand){
       
        for(int i = 0; i < hand.cards.size(); i++){
            cards.add(hand.cards.get(i));
        }
        
    }
    
    public void addCollection(ArrayList<Card> newCollection){
        
        for(Card c:newCollection){
            cards.add(c);
        }
        
    }
    
    public void addCard(Card card){
        
        cards.add(card);
//        countRanksAndSuits();
        
    }
    
    public void countRanksAndSuits(){
        
        int rank;
        int suit;
        Card card;
        
        
        for(int i = 0; i < suitCount.length; i++){
            
            suitCount[i] = 0;
            
        }
        
        for(int i = 0; i < rankCount.length; i++){
            
            rankCount[i] = 0;
            
        }
        
        for(int i = 0; i < cards.size(); i++){
            
            card = cards.get(i);
            suitCount[card.getSuit().ordinal()]++;
            rankCount[card.getRank().ordinal()]++;
            
        }
        
    }

    public int countRank (Card.Rank rank){
        int numberOfRanks = 0;
        for(int i = 0; i < cards.size(); i++){
            Card c = cards.get(i);
            if(c.getRank().equals(rank)){
                numberOfRanks++;
            }
        }
        
        return numberOfRanks;
    }
    
    public int countSuit(Card.Suit suit){
        
        int numberOfSuits = 0;
        for(Card c:cards){
            if(c.getSuit() == suit){
                numberOfSuits++;
            }
        }
        
        return numberOfSuits;
    }
    
    public void sortAscending(){
        
        Card thisCard;
        int cardMin;        
                
        for(int i = 0; i < cards.size(); i++){              
            
            cardMin = i;            
            
            for(int j = i; j < cards.size(); j++){
                if(cards.get(cardMin).compareTo(cards.get(j)) == 1){
                    cardMin = j;                    
                }                        
            }
            Collections.swap(cards, i, cardMin);
        }
    }
    
    public void sortDescending(){
        
        Collections.sort(cards, new Card.CompareDescending());
        
    }
       
    public Card getCard(int index){
        return cards.get(index);
    }
    
    public int getHandSize(){
        return cards.size();
    }
    
    public ArrayList<Card> getCards(){
        return cards;
    }
    
    @Override
    public Iterator<Card> iterator() {
        
        OrderAdded oa = new OrderAdded();
        
        return oa;
        
    }
    
    public class OrderAdded implements Iterator<Card>{

        int index = 0;
        int size = 0;
        
        public OrderAdded(){
            size = cards.size() - 1;
        }
        
        @Override
        public boolean hasNext() {
            
            if((index) > size){                                
                 
                return false;                
            }
            
            return true;
        }

        @Override
        public Card next() {
            
            Card card;
            
            if(hasNext()){                
                card = cards.get(index);                                
                index++;   
                return card;
            } else {
                return null;
            } 
            
        }
        
        @Override
        public void remove(){
            cards.remove(index);
        }        
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        countRanksAndSuits();
        handValue();
        str.append("Hand{");
        str.append("cards=");
        str.append(cards);        
        str.append(", handTotalValue=");
        str.append(handTotalValue);
        str.append('}');
        return str.toString();
    }
    
    
}
